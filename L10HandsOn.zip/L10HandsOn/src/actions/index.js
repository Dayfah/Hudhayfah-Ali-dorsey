export const increment = () => ({
  type: 'INCREMENT'
});

export const decrement = () => ({
  type: 'DECREMENT'
});

export const reset = () => ({
  type: 'RESET'
});

export const inputNumber = () => ({
  type: 'Input_Number'
});

export const inputNUmberChange = () => ({
  type: 'Input_Number_Change',
  number
});

